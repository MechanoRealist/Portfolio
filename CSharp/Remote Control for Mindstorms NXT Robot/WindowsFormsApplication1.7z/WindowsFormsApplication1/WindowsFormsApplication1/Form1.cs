﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using NKH.MindSqualls;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    { 
        NxtBrick brick;
        
        NxtMotor motorA;
        NxtMotor motorB;
        NxtMotor motorC;

        // Syncronize the two motors.
        NxtMotorSync motorPair;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Create a NXT brick,
            // and use Bluetooth on COM40 to communicate with it.


//OBS       HVIS den skal køre med Bluetooth så skal denne linje være aktiv!!!
          brick = new NxtBrick(NxtCommLinkType.Bluetooth, 3);

//OBS       Hvis den skal køre med USB skal denne linje være aktiv!!!
            // Create a NXT brick,
            // and use USB to communicate with it.
//            NxtBrick brick = new NxtBrick(NxtCommLinkType.USB, 0);

            
            // Create a motor.
            motorA = new NxtMotor();
            motorB = new NxtMotor();
            motorC = new NxtMotor();

            // Attach it to port A of the NXT brick.
            brick.MotorA = motorA;
            brick.MotorB = motorB;
            brick.MotorC = motorC;

            motorPair = new NxtMotorSync(brick.MotorB, brick.MotorC);

            // Connect to the NXT.
            brick.Connect();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            sbyte sbPower = 0;
            int iPower = 0;
            uint uigrader = 0;
            long lgrader = 0;
            string message = "";
            string caption_sbyte = "Fejl i power indtastningen";
            bool KraftReady = false;
            bool GradReady = false;

            DialogResult result;

            // Læs http://www.mindsqualls.net/QuickStart_2_0.aspx for mere...

            if (!sbyte.TryParse(textBox1.Text, out sbPower))
            {
                if (int.TryParse(textBox1.Text, out iPower))
                {
                    if (iPower < 0)
                        message = "Motor kraft tallet er for lille! Tallet skal være mellem -128 og 127!";
                    else
                        message = "Motor kraft tallet er for stort! Tallet skal være mellem -128 og 127!";
                }
                else
                    message = "Der skal stå et heltal i 'Motor kraft' feltet! Tallet skal være mellem -128 og 127!";

                MessageBoxButtons buttons = MessageBoxButtons.OK;

                // Displays the MessageBox.
                result = MessageBox.Show(message, caption_sbyte, buttons);
                
                KraftReady = false;
            }
            else
                KraftReady = true;

            if (!uint.TryParse(textBox2.Text, out uigrader))
            {
                if (long.TryParse(textBox2.Text, out lgrader))
                {
                    if (lgrader < 0)
                        message = "Motor grad tallet er for lille! Tallet skal være mellem 0 og 4,294,967,295!";
                    else
                        message = "Motor grad tallet er for stort! Tallet skal være mellem 0 og 4,294,967,295!";
                }
                else
                    message = "Der skal stå et heltal i 'Motor grad' feltet! Tallet skal være mellem 0 og 4,294,967,295!";

                MessageBoxButtons buttons = MessageBoxButtons.OK;

                // Displays the MessageBox.
                result = MessageBox.Show(message, caption_sbyte, buttons);
                
                GradReady = false;
            }
            else
                GradReady = true;

            // Power står i textbox1 og degrees står i textbox2
 //           if (sbyte.Parse(textBox1.Text) < 0 || sbyte.Parse(textBox1.Text) < 0)

            if (KraftReady && GradReady)
                motorA.Run(sbyte.Parse(textBox1.Text),uint.Parse(textBox2.Text));
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Disconnect from the NXT.
            brick.Disconnect();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Run left motor
            motorB.Run(50, 90);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Run right motor
            motorC.Run(50, 90);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Run both moptors
            motorB.Run(50, 90);
            motorC.Run(50, 90);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            motorB.Run(-50, 90);
            motorC.Run(-50, 90);
        }

        private void uSBBluetoothToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
