﻿using System;

namespace Autorepairshop_Case
{
    public static class ConsoleHelper
    {
        public static int Menu(bool canCancel, int prline,int y,int x, params string[] options)
        {

            int startX = x;// en constant integer variable med den faste værdi af 10
            int startY = y;
            int optionsPrLine = prline;
            const int spacing = 35;

            int currentChoice = 0;// en integer variable med en given værdi af 0 (første værdi i menuen)

            ConsoleKey key;// en consolekey variable uden given værdi til senere brug i methoden

            Console.CursorVisible = false;// gør så man ikke can se hvor cursor er og dermed ikke kan se hvor consolen er i gang med at skrive

            do// en do while statement der køre indtil brugeren trykker på enter
            {
                Program.MenuBottom.Clear();
                for (int i = 0; i < options.Length; i++)//et for loop der køre lige så længe som der er muligheder tilbage
                {
                    Console.SetCursorPosition(startX + (i % optionsPrLine) * spacing, startY + i / optionsPrLine);// sætter cursor på den valgte genstan udregnet af formlen

                    if (i == currentChoice)// en if statement der kontrollere om i er på en valgmulighed og vis den er udføre koden under
                    {
                        Console.BackgroundColor = ConsoleColor.Red;// skifter baggrunds farven på den valgte genstan
                    }
                    Console.Write(options[i]);// udskriver alle mulighederne en efter en som loopet køre igennem

                    Console.ResetColor();// sætter farven tilbage til normal sort baggrund med hvid tekst
                }

                key = Console.ReadKey(true).Key;//læser hvilken tast brugeren trykker på og gæmmer det i Key variablen

                switch (key)// en switch case der kigger efter hvilken værdi der er gæmt i Key
                {
                    case ConsoleKey.LeftArrow:// en case som køre vis brugeren trykkede på pil til venstre
                        {
                            if (currentChoice % optionsPrLine > 0)// en if statement der kontrollere at brugeren ikke går ud fra menu mulighederne vis dne ikke gør kørere den linjen under
                                currentChoice--;// minuser en i nuværenevalg variablen og dermed går en mulighed tilbage
                            break;// afslutter nuværende case
                        }
                    case ConsoleKey.RightArrow:
                        {
                            if (currentChoice % optionsPrLine < optionsPrLine - 1)
                                currentChoice++;
                            break;
                        }
                    case ConsoleKey.UpArrow:
                        {
                            if (currentChoice >= optionsPrLine)
                                currentChoice -= optionsPrLine;
                            break;
                        }
                    case ConsoleKey.DownArrow:
                        {
                            if (currentChoice + optionsPrLine < options.Length)
                                currentChoice += optionsPrLine;
                            break;
                        }
                    case ConsoleKey.Escape:
                        {
                            if (canCancel)// vis menuen har modtaget en true variable på canCancel's plads da man sendte dne hertil vil du have mulighed for at lukke programmet automatisk
                                return -1;// reutrnere en værdi af -1 hviket ikke er en mulighed i menuens switch case i Program/menu.cs filerne og programemt vildermed bare lukke ned
                            break;
                        }
                }
            } while (key != ConsoleKey.Enter);
            Console.CursorVisible = true;// sætter cursor som synlig igen så brugeren kan se hvor han skriver igen
            return currentChoice;//værdien i nuværendeValg bliver nu plusset med et da hele menuen startedede i 0 og vores switch cases er lavet uden en 0 mulighed
        }
        

        public static void DrawVertical(int topNode, int bottomNode, int horizontal, char symbol)
        {
            for (int i = topNode; i < bottomNode; i++)
            {
                Console.SetCursorPosition(horizontal, i);
                Console.Write(symbol);
            }
        }
        public static void DrawHorizontal(int leftNode, int rightNode, int vertical, char symbol)
        {
            Console.SetCursorPosition(leftNode, vertical);
            Console.WriteLine(new string(symbol, rightNode - leftNode));
        }
        public static void DrawSingle(int left, int top, char symbol)
        {
            Console.SetCursorPosition(left, top);
            Console.Write(symbol);
        }

        public static void PrintLines(int left, int top, params string[] lines)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                Console.SetCursorPosition(left, top + 2 * i);
                Console.Write(lines[i]);
            }
        }

        public static void ClearBox(int left, int top, int width, int lines)
        {
            string clearLine = new string(' ', width);
            for (int i = 0; i < lines; i++)
            {
                Console.SetCursorPosition(left, top + i);
                Console.Write(clearLine);
            }
        }
    }
}
