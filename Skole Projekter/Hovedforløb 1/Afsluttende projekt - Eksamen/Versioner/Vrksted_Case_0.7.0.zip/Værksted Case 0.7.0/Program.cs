﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autorepairshop_Case
{
    class Program
    {

        public static int HalfWindowWidth
        {
            get { return Console.WindowWidth / 2; }
        }
        public static int TwoThirdsWindowHieght
        {
            get { return Console.WindowHeight / 3 * 2; }
        }
        public static MenuBox MenuLeft { get; set; }
        public static MenuBox MenuRight { get; set; }
        public static MenuBox MenuBottom { get; set; }
        public static void Main()
        {
            MenuLeft = new MenuBox { LeftBoundary = 0, RightBoundary = HalfWindowWidth - 1, TopBoundary = 0, BottomBoundary = TwoThirdsWindowHieght - 1 };
            MenuRight = new MenuBox { LeftBoundary = HalfWindowWidth+1, RightBoundary = Console.WindowWidth, TopBoundary = 0, BottomBoundary = TwoThirdsWindowHieght - 1 };
            MenuBottom = new MenuBox { LeftBoundary = 0, RightBoundary = Console.WindowWidth, TopBoundary = TwoThirdsWindowHieght+2, BottomBoundary = Console.WindowHeight };


            DrawFrame();
            int menuChoice = ConsoleHelper.Menu(false, 3, MenuBottom.TopBoundary + 2, MenuBottom.LeftBoundary + 10, "Edit/Read Cars", "Edit/Read Customers", "Edit/Read Servicings");
            switch(menuChoice)
            {
                case 0:
                    Car.Menu();
                    break;
                case 1:
                    Customer.Menu();
                    break;
                case 2:
                    CarServicing.Menu();
                    break;
            }

            Console.WriteLine("U made it to the end somehow");
            Console.ReadLine();
        }

        public static void DrawFrame()
        {
            ConsoleHelper.DrawHorizontal(0, Console.WindowWidth, TwoThirdsWindowHieght, '─');
            ConsoleHelper.DrawVertical(0, TwoThirdsWindowHieght, HalfWindowWidth, '│');
            ConsoleHelper.DrawSingle(HalfWindowWidth, TwoThirdsWindowHieght, '┴');
            Console.SetCursorPosition(0, 0);
        }
    }
}
