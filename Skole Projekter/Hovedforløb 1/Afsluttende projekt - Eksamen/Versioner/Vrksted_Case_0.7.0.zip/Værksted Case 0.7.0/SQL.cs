﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Autorepairshop_Case
{
    class SQL
    {
        public static SqlConnection sqlConnection = new SqlConnection(@"Data Source=tcp:80.197.69.234;Initial Catalog=Autorepairshop;Persist Security Info=True;User ID=nimdA;Password=Changeme123"); // en string der holder login info til sql databasen til Remote connection (Rasmus Computer)
        //public static SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-6M9QTUB;Initial Catalog=Autorepairshop;Persist Security Info=True;User ID=nimdA;Password=Changeme123"); // en string der holder login info til sql databasen til Remote connection (Rasmus Computer)

        /// <summary>
        /// Henter en tabel fra databasen og lægger den ind i et DataTable objekt
        /// </summary>
        /// <param name="querySelect"></param>
        /// <returns></returns>
        public static DataTable GetTable(string querySelect)
        {
            SqlCommand cmd = new SqlCommand(querySelect, sqlConnection);
            DataTable table = new DataTable();
            sqlConnection.Open();
            try
            {
                SqlDataReader reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (Exception)
            {
                throw;
            }
            finally { sqlConnection.Close(); }
            return table;
        }
        /// <summary>
        /// Udfører SQL kommandoer som foretager ændringer i databasen
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public static int SqlNonQuery(params SqlCommand[] cmds)
        {
            int rowsAffected = 0;
            
            sqlConnection.Open();
            try
            {
                for (int i = 0; i < cmds.Length; i++)
                {
                    cmds[i].Connection = sqlConnection;
                    rowsAffected += cmds[i].ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally { sqlConnection.Close(); }
            return rowsAffected;
        }
    }
}
