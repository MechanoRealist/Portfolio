﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Autorepairshop_Case
{
    class Customer : IDatabaseObject
    {
        public int CustomerID { get; private set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Address { get; set; }
        public int TelephoneNr { get; set; }
        public DateTime CreationDate { get; set; }



        //Create og Remove arbejder på objektet selv.
        public int Create()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Customers VALUES(@fname, @lname, @address, @tlf);");
            SqlParameter[] parameters = new SqlParameter[] { //SQL parametre begrænser hvad der kan indtastes i variablerne.
                new SqlParameter("@fname", SqlDbType.NVarChar, 60),
                new SqlParameter("@lname", SqlDbType.NVarChar, 60),
                new SqlParameter("@address", SqlDbType.NVarChar, 60),
                new SqlParameter("@tlf", SqlDbType.Int)
            };
            cmd.Parameters.AddRange(parameters);
            parameters[0].Value = Firstname;
            parameters[1].Value = Lastname;
            parameters[2].Value = Address;
            parameters[3].Value = TelephoneNr;

            return SQL.SqlNonQuery(cmd);
        }

        public int Update()
        {

            return -1;
        }

        public int Delete()
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Customers WHERE customerID=@idParam;");
            SqlParameter idParam = new SqlParameter("@idParam", SqlDbType.Int);
            cmd.Parameters.Add(idParam);
            idParam.Value = CustomerID;

            return SQL.SqlNonQuery(cmd);
        }
        /// <summary>
        /// Henter tabellen Kunder fra databasen og lægger den ind i en liste af Kunde objekter
        /// </summary>
        /// <returns></returns>
        public static List<Customer> GetList()
        {
            List<Customer> customers = new List<Customer>();
            DataTable table = SQL.GetTable("SELECT * FROM Customers");
            DataTableReader reader = table.CreateDataReader();

            while (reader.Read())
            {
                customers.Add(new Customer
                {
                    CustomerID = (int)reader.GetValue(0),
                    Firstname = (string)reader.GetValue(1),
                    Lastname = (string)reader.GetValue(2),
                    Address = (string)reader.GetValue(3),
                    TelephoneNr = (int)reader.GetValue(4),
                    CreationDate = (DateTime)reader.GetValue(5)
                });
            }
            return customers;
        }
        
        public static void PrintList(List<Customer> list)
        {
            foreach (Customer i in list)
            {
                Console.WriteLine("{0,-20}{1,-20}{2,-20}{3,-20}{4,-20}{5,-20:dd-MM-yyyy}",
                    i.CustomerID, i.Firstname, i.Lastname, i.Address, i.TelephoneNr, i.CreationDate);
            }
        }
    }
}
