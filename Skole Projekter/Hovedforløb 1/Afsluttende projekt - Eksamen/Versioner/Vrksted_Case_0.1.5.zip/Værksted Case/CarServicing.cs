﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Autorepairshop_Case
{
    class CarServicing : IDatabaseObject
    {
        public int VisitNr { get; private set; }
        public DateTime Arrival { get; set; }
        public string Numberplate { get; set; }
        public double Price { get; set; }
        public string IssueDescription { get; set; }
        public string MechanicsNotes { get; set; }

        //Create og Remove arbejder på objektet selv.
        
        public int Create()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO CarServicings VALUES(@numberplate, @price, @issueDescription, @mechanicsNotes);");
            SqlParameter[] parameters = new SqlParameter[] {
                new SqlParameter("@numberplate", SqlDbType.VarChar, 255),
                new SqlParameter("@price", SqlDbType.Money),
                new SqlParameter("@issueDescription", SqlDbType.Text),
                new SqlParameter("@mechanicsNotes", SqlDbType.Text)
            };
            cmd.Parameters.AddRange(parameters);
            
            parameters[0].Value = Numberplate;
            parameters[1].Value = Price;
            parameters[2].Value = IssueDescription;
            if (MechanicsNotes == "")
            {
                parameters[3].Value = DBNull.Value;
            }
            else
            {
                parameters[3].Value = MechanicsNotes;
            }
            
            return SQL.SqlNonQuery(cmd);
        }

        public int Update()
        {
            return -1;
        }

        //Fjerner en Værkstedsbesøg fra databasen
        public int Delete()
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM CarServicings WHERE VisitNr=@idParam;");
            SqlParameter idParam = new SqlParameter("@idParam", SqlDbType.Int);
            cmd.Parameters.Add(idParam);
            idParam.Value = VisitNr;

            return SQL.SqlNonQuery(cmd);
        }
        /// <summary>
        /// Henter tabellen Værkstedsbesøger fra databasen og lægger den ind i en liste af Værkstedsbesøg objekter
        /// </summary>
        /// <returns></returns>
        public static List<CarServicing> GetList()
        {
            List<CarServicing> carServicings = new List<CarServicing>();
            DataTable table = SQL.GetTable("SELECT * FROM CarServicings");
            DataTableReader reader = table.CreateDataReader();

            while (reader.Read())
            {
                carServicings.Add(new CarServicing
                {
                    VisitNr = (int)reader.GetValue(0),
                    Arrival = (DateTime)reader.GetValue(1),
                    Numberplate = (string)reader.GetValue(2),
                    Price = (double)reader.GetValue(3),
                    IssueDescription = (string)reader.GetValue(4),////////// string og problem beskrivelse
                    MechanicsNotes = reader.GetValue(5) == DBNull.Value ? "" : (string)reader.GetValue(4) // DBNull (SQL) så den kan genkendes i C#//////////////// mekaniker noter
                });
            }
            return carServicings;
        }
        /// <summary>
        /// Udskriver data fra en liste af Værkstedsbesøg objekter i konsollen
        /// </summary>
        /// <param name="list"></param>
        public static void PrintList(List<CarServicing> list)
        {
            foreach (CarServicing i in list)
            {
                Console.WriteLine("{0,-20}{1,-20:dd-MM-yyyy}{2,-20}{3,-20}{4,-20}{5,-20}",//ikke rørt forklaring tak (igen)/////Det er formatering og padding af udskrivningen med properties
                    i.VisitNr, i.Arrival, i.Numberplate, i.Price, i.IssueDescription, i.MechanicsNotes); //rettet til værstedsbesøg
            }
        }
    }
}
