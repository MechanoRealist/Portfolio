﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Autorepairshop_Case
{
    class Car : IDatabaseObject 
    {
        public string Numberplate { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string SerialNr { get; set; }
        public int CustomerID { get; set; }

        public static void Menu()
        {
            int choice = ConsoleHelper.Menu(false,3, Program.MenuBottom.TopBoundary + 2, Program.MenuBottom.LeftBoundary + 10, "Read/Edit current Car", "Create new Car", "Delete a Car");
            switch (choice)
            {
                case 0:
                    Reader();
                    break;
                case 1:
                    Creator();
                    break;
                case 2:
                    Deletor();
                    break;
            }
            
            Program.Main();
        }
        public static void Deletor()
        {
            string[] options = ExtractUnique(Program.Cars);
            int listIndex = ConsoleHelper.Menu(true, 1, 0, 0, options);
            Car highlighted = Program.Cars[listIndex];
            highlighted.Delete();
        }
        public static void Creator()
        {
            Car newCar = new Car();
            string[] descriptions = new string[] { "Plate: ", "Licence Plate: ", "Brand: ", "Serial Number: " };
            Program.MenuLeft.PrintContent(descriptions);
            Console.SetCursorPosition(Program.MenuLeft.LeftBoundary + descriptions[0].Length, 0);
            newCar.Numberplate = Console.ReadLine();
            Console.SetCursorPosition(Program.MenuLeft.LeftBoundary + descriptions[1].Length, 1);
            newCar.Brand = Console.ReadLine();
            Console.SetCursorPosition(Program.MenuLeft.LeftBoundary + descriptions[2].Length, 2);
            newCar.Model = Console.ReadLine();
            Console.SetCursorPosition(Program.MenuLeft.LeftBoundary + descriptions[3].Length, 3);
            newCar.SerialNr = Console.ReadLine();
            Console.SetCursorPosition(Program.MenuLeft.LeftBoundary + descriptions[4].Length, 4);
            newCar.CustomerID = Convert.ToInt32(Console.ReadLine());
            newCar.Create();
            Program.MenuLeft.Clear();
        }
        public static void Reader()
        {
            string[] options = ExtractUnique(Program.Cars);
            int listIndex = ConsoleHelper.Menu(true, 1, 0, 0, options);
            Car highlighted = Program.Cars[listIndex];
            string[] descriptions = new string[] { "Licence Plate: ", "Brand: ", "Model: ", "Serial Number: ", "CustomerID: " };
            string[] lines = new string[]
            {
                descriptions[0] + highlighted.Numberplate,
                descriptions[1] + highlighted.Brand,
                descriptions[2] + highlighted.Model.ToString(),
                descriptions[3] + highlighted.SerialNr,
                descriptions[4] + highlighted.CustomerID
            };

            Program.MenuRight.PrintContent(lines);
            Console.SetCursorPosition(Program.MenuRight.LeftBoundary + descriptions[0].Length, 0);
            string input;
            //input = Console.ReadLine();
            //if (!(input == ""))
            //{
            //    highlighted.Numberplate = input;
            //}

            Console.SetCursorPosition(Program.MenuRight.LeftBoundary + descriptions[1].Length, 2);

            input = Console.ReadLine();
            if (!(input == ""))
            {
                highlighted.Brand = input;
            }
            Console.SetCursorPosition(Program.MenuRight.LeftBoundary + descriptions[2].Length, 4);

            input = Console.ReadLine();
            if (!(input == ""))
            {
                highlighted.Model = input;
            }
            Console.SetCursorPosition(Program.MenuRight.LeftBoundary + descriptions[3].Length, 6);

            input = Console.ReadLine();
            if (!(input == ""))
            {
                highlighted.SerialNr = input;
            }
            Console.SetCursorPosition(Program.MenuRight.LeftBoundary + descriptions[4].Length, 8);

            input = Console.ReadLine();
            if (!(input == ""))
            {
                highlighted.CustomerID = Convert.ToInt32(input);
            }
            highlighted.Update();
        }
        public static string[] ExtractUnique(List<Car> list)
        {

            string[] options = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
            {
                options[i] = list[i].CustomerID.ToString() + "    " + list[i].Numberplate; //+ ""+list[i].;
            }

            return options;
        }


        //Tilføjer en Bil til databasen
        #region SQL Commands
        public int Create()
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Cars VALUES(@numberplate, @brand, @model, @serialNr, @customerID);");
            SqlParameter[] parameters = new SqlParameter[] {
                new SqlParameter("@numberplate", SqlDbType.VarChar, 255),
                new SqlParameter("@brand", SqlDbType.VarChar, 255),
                new SqlParameter("@model", SqlDbType.VarChar, 255),
                new SqlParameter("@serialNr", SqlDbType.VarChar, 255),
                new SqlParameter("@customerID", SqlDbType.Int)
            };
            cmd.Parameters.AddRange(parameters);
            parameters[0].Value = Numberplate;
            parameters[1].Value = Brand;
            parameters[2].Value = Model;
            parameters[3].Value = SerialNr;
            parameters[4].Value = CustomerID;
            return SQL.SqlNonQuery(cmd);
        }

        public int Update()
        {
            SqlCommand cmd = new SqlCommand("UPDATE Cars SET brand=@Brand, model=@Model, serialNr=@SerialNr WHERE customerID=@customerID");
            SqlParameter[] parameters = new SqlParameter[] {
                new SqlParameter("@brand", SqlDbType.VarChar, 255),
                new SqlParameter("@model", SqlDbType.VarChar, 255),
                new SqlParameter("@serialNr", SqlDbType.VarChar, 255),
                new SqlParameter("@customerID", SqlDbType.Int)
            };
            cmd.Parameters.AddRange(parameters);
            parameters[0].Value = Brand;
            parameters[1].Value = Model;
            parameters[2].Value = SerialNr;
            parameters[3].Value = CustomerID;
            return SQL.SqlNonQuery(cmd);

        }

        //Fjerner en Bil fra databasen
        public int Delete()
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Cars WHERE numberplate=@idParam;");
            SqlParameter idParam = new SqlParameter("@idParam", SqlDbType.Int);
            cmd.Parameters.Add(idParam);
            idParam.Value = Numberplate;

            return SQL.SqlNonQuery(cmd);
        }
        #endregion

        public static List<Car> GetList()
        {
            List<Car> cars = new List<Car>();
            DataTable table = SQL.GetTable("SELECT * FROM Cars");
            DataTableReader reader = table.CreateDataReader();

            while (reader.Read())
            {
                cars.Add(new Car
                {
                    Numberplate = (string)reader.GetValue(0),
                    Brand = (string)reader.GetValue(1),
                    Model = (string)reader.GetValue(2),
                    SerialNr = (string)reader.GetValue(3),
                    CustomerID = (int)reader.GetValue(4)
                });
            }
            return cars;
        }
        
        public static void PrintList(List<Car> list)
        {
            foreach (Car i in list)
            {
                Console.WriteLine("{0,-20}{1,-20}{2,-20}{3,-20:dd-MM-yyyy}{4,-20}",
                    i.Numberplate, i.Brand, i.Model, i.SerialNr, i.CustomerID);
            }
        }
    }
}
