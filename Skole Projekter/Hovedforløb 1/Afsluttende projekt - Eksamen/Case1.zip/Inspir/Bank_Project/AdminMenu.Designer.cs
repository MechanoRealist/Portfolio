﻿namespace Bank_Project
{
    partial class AdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kundeKnap = new System.Windows.Forms.Button();
            this.kontoKnap = new System.Windows.Forms.Button();
            this.NewAccKnap = new System.Windows.Forms.Button();
            this.lukKnap = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.NewCustomerKnap = new System.Windows.Forms.Button();
            this.labelKontoID = new System.Windows.Forms.Label();
            this.kontoTypeBox = new System.Windows.Forms.TextBox();
            this.labelRente = new System.Windows.Forms.Label();
            this.renteBox = new System.Windows.Forms.TextBox();
            this.labelSaldo = new System.Windows.Forms.Label();
            this.saldoBox = new System.Windows.Forms.TextBox();
            this.labelKundeID = new System.Windows.Forms.Label();
            this.kundeIDBox = new System.Windows.Forms.TextBox();
            this.lavKontoKnap = new System.Windows.Forms.Button();
            this.tableLayoutPanelAccount = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelCustomer = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.adresseBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.firmaBox = new System.Windows.Forms.TextBox();
            this.fornavnBox = new System.Windows.Forms.TextBox();
            this.tlfBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.kundeTypeBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.efternavnBox = new System.Windows.Forms.TextBox();
            this.lavKundeKnap = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanelRedigerKunde = new System.Windows.Forms.TableLayoutPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.editFirmanavnBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.editKundeTypeBox = new System.Windows.Forms.TextBox();
            this.editTlfBox = new System.Windows.Forms.TextBox();
            this.editKudnIDBox = new System.Windows.Forms.TextBox();
            this.editAdresseBox = new System.Windows.Forms.TextBox();
            this.editEfternavBox = new System.Windows.Forms.TextBox();
            this.editnavnBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tableLayoutPaneleditAccount = new System.Windows.Forms.TableLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.editPinkodeBox = new System.Windows.Forms.TextBox();
            this.editSaldoBox = new System.Windows.Forms.TextBox();
            this.editRenteBox = new System.Windows.Forms.TextBox();
            this.editKontoTypeBox = new System.Windows.Forms.TextBox();
            this.editKontoIDBox = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.editEjerBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.søgKontoIDBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanelkundersøg = new System.Windows.Forms.TableLayoutPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.søgNavnBox = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button5 = new System.Windows.Forms.Button();
            this.tableLayoutPanelsøgTransaktion = new System.Windows.Forms.TableLayoutPanel();
            this.sletTransaktionBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.søgTransaktionBox = new System.Windows.Forms.TextBox();
            this.sletKundeKnap = new System.Windows.Forms.Button();
            this.sletKontoKnap = new System.Windows.Forms.Button();
            this.tableLayoutPanelAccount.SuspendLayout();
            this.tableLayoutPanelCustomer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tableLayoutPanelRedigerKunde.SuspendLayout();
            this.tableLayoutPaneleditAccount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tableLayoutPanelkundersøg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanelsøgTransaktion.SuspendLayout();
            this.SuspendLayout();
            // 
            // kundeKnap
            // 
            this.kundeKnap.Location = new System.Drawing.Point(3, 2);
            this.kundeKnap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kundeKnap.Name = "kundeKnap";
            this.kundeKnap.Size = new System.Drawing.Size(157, 95);
            this.kundeKnap.TabIndex = 0;
            this.kundeKnap.Text = "Administrate Customers";
            this.kundeKnap.UseVisualStyleBackColor = true;
            this.kundeKnap.Click += new System.EventHandler(this.KundeKnap_Click);
            // 
            // kontoKnap
            // 
            this.kontoKnap.Location = new System.Drawing.Point(199, 2);
            this.kontoKnap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kontoKnap.Name = "kontoKnap";
            this.kontoKnap.Size = new System.Drawing.Size(157, 95);
            this.kontoKnap.TabIndex = 1;
            this.kontoKnap.Text = "Administrate   Accounts";
            this.kontoKnap.UseVisualStyleBackColor = true;
            this.kontoKnap.Click += new System.EventHandler(this.KontoKnap_Click);
            // 
            // NewAccKnap
            // 
            this.NewAccKnap.Location = new System.Drawing.Point(591, 2);
            this.NewAccKnap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NewAccKnap.Name = "NewAccKnap";
            this.NewAccKnap.Size = new System.Drawing.Size(157, 95);
            this.NewAccKnap.TabIndex = 2;
            this.NewAccKnap.Text = "New Account";
            this.NewAccKnap.UseVisualStyleBackColor = true;
            this.NewAccKnap.Click += new System.EventHandler(this.NewAccKnap_Click);
            // 
            // lukKnap
            // 
            this.lukKnap.BackColor = System.Drawing.Color.Red;
            this.lukKnap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.lukKnap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lukKnap.Location = new System.Drawing.Point(1036, -1);
            this.lukKnap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lukKnap.Name = "lukKnap";
            this.lukKnap.Size = new System.Drawing.Size(20, 23);
            this.lukKnap.TabIndex = 6;
            this.lukKnap.Text = "X";
            this.lukKnap.UseVisualStyleBackColor = false;
            this.lukKnap.Click += new System.EventHandler(this.LukKnap_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(476, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Admin Menu";
            // 
            // NewCustomerKnap
            // 
            this.NewCustomerKnap.Location = new System.Drawing.Point(787, 2);
            this.NewCustomerKnap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NewCustomerKnap.Name = "NewCustomerKnap";
            this.NewCustomerKnap.Size = new System.Drawing.Size(157, 95);
            this.NewCustomerKnap.TabIndex = 8;
            this.NewCustomerKnap.Text = "New Customer";
            this.NewCustomerKnap.UseVisualStyleBackColor = true;
            this.NewCustomerKnap.Click += new System.EventHandler(this.NewCustomerKnap_Click);
            // 
            // labelKontoID
            // 
            this.labelKontoID.AutoSize = true;
            this.labelKontoID.Location = new System.Drawing.Point(3, 0);
            this.labelKontoID.Name = "labelKontoID";
            this.labelKontoID.Size = new System.Drawing.Size(85, 17);
            this.labelKontoID.TabIndex = 13;
            this.labelKontoID.Text = "Konto Type:";
            // 
            // kontoTypeBox
            // 
            this.kontoTypeBox.Location = new System.Drawing.Point(103, 2);
            this.kontoTypeBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kontoTypeBox.Name = "kontoTypeBox";
            this.kontoTypeBox.Size = new System.Drawing.Size(93, 22);
            this.kontoTypeBox.TabIndex = 12;
            // 
            // labelRente
            // 
            this.labelRente.AutoSize = true;
            this.labelRente.Location = new System.Drawing.Point(3, 94);
            this.labelRente.Name = "labelRente";
            this.labelRente.Size = new System.Drawing.Size(50, 17);
            this.labelRente.TabIndex = 15;
            this.labelRente.Text = "Rente:";
            // 
            // renteBox
            // 
            this.renteBox.Location = new System.Drawing.Point(103, 96);
            this.renteBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.renteBox.Name = "renteBox";
            this.renteBox.Size = new System.Drawing.Size(93, 22);
            this.renteBox.TabIndex = 14;
            // 
            // labelSaldo
            // 
            this.labelSaldo.AutoSize = true;
            this.labelSaldo.Location = new System.Drawing.Point(3, 47);
            this.labelSaldo.Name = "labelSaldo";
            this.labelSaldo.Size = new System.Drawing.Size(48, 17);
            this.labelSaldo.TabIndex = 17;
            this.labelSaldo.Text = "Saldo:";
            // 
            // saldoBox
            // 
            this.saldoBox.Location = new System.Drawing.Point(103, 49);
            this.saldoBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saldoBox.Name = "saldoBox";
            this.saldoBox.Size = new System.Drawing.Size(93, 22);
            this.saldoBox.TabIndex = 16;
            // 
            // labelKundeID
            // 
            this.labelKundeID.AutoSize = true;
            this.labelKundeID.Location = new System.Drawing.Point(3, 140);
            this.labelKundeID.Name = "labelKundeID";
            this.labelKundeID.Size = new System.Drawing.Size(70, 17);
            this.labelKundeID.TabIndex = 19;
            this.labelKundeID.Text = "Kunde ID:";
            // 
            // kundeIDBox
            // 
            this.kundeIDBox.Location = new System.Drawing.Point(103, 142);
            this.kundeIDBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kundeIDBox.Name = "kundeIDBox";
            this.kundeIDBox.Size = new System.Drawing.Size(93, 22);
            this.kundeIDBox.TabIndex = 18;
            // 
            // lavKontoKnap
            // 
            this.lavKontoKnap.Location = new System.Drawing.Point(64, 228);
            this.lavKontoKnap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lavKontoKnap.Name = "lavKontoKnap";
            this.lavKontoKnap.Size = new System.Drawing.Size(112, 95);
            this.lavKontoKnap.TabIndex = 20;
            this.lavKontoKnap.Text = "Create Account";
            this.lavKontoKnap.UseVisualStyleBackColor = true;
            this.lavKontoKnap.Visible = false;
            this.lavKontoKnap.Click += new System.EventHandler(this.LavKontoKnap_Click);
            // 
            // tableLayoutPanelAccount
            // 
            this.tableLayoutPanelAccount.ColumnCount = 2;
            this.tableLayoutPanelAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelAccount.Controls.Add(this.kontoTypeBox, 1, 0);
            this.tableLayoutPanelAccount.Controls.Add(this.renteBox, 1, 2);
            this.tableLayoutPanelAccount.Controls.Add(this.labelKundeID, 0, 3);
            this.tableLayoutPanelAccount.Controls.Add(this.kundeIDBox, 1, 3);
            this.tableLayoutPanelAccount.Controls.Add(this.labelKontoID, 0, 0);
            this.tableLayoutPanelAccount.Controls.Add(this.labelSaldo, 0, 1);
            this.tableLayoutPanelAccount.Controls.Add(this.labelRente, 0, 2);
            this.tableLayoutPanelAccount.Controls.Add(this.saldoBox, 1, 1);
            this.tableLayoutPanelAccount.Location = new System.Drawing.Point(20, 50);
            this.tableLayoutPanelAccount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanelAccount.Name = "tableLayoutPanelAccount";
            this.tableLayoutPanelAccount.RowCount = 4;
            this.tableLayoutPanelAccount.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelAccount.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelAccount.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanelAccount.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanelAccount.Size = new System.Drawing.Size(200, 171);
            this.tableLayoutPanelAccount.TabIndex = 21;
            this.tableLayoutPanelAccount.Visible = false;
            // 
            // tableLayoutPanelCustomer
            // 
            this.tableLayoutPanelCustomer.ColumnCount = 2;
            this.tableLayoutPanelCustomer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.5F));
            this.tableLayoutPanelCustomer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.5F));
            this.tableLayoutPanelCustomer.Controls.Add(this.label7, 0, 5);
            this.tableLayoutPanelCustomer.Controls.Add(this.adresseBox, 0, 5);
            this.tableLayoutPanelCustomer.Controls.Add(this.label6, 0, 4);
            this.tableLayoutPanelCustomer.Controls.Add(this.firmaBox, 0, 4);
            this.tableLayoutPanelCustomer.Controls.Add(this.fornavnBox, 1, 0);
            this.tableLayoutPanelCustomer.Controls.Add(this.tlfBox, 1, 2);
            this.tableLayoutPanelCustomer.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanelCustomer.Controls.Add(this.kundeTypeBox, 1, 3);
            this.tableLayoutPanelCustomer.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanelCustomer.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanelCustomer.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanelCustomer.Controls.Add(this.efternavnBox, 1, 1);
            this.tableLayoutPanelCustomer.Location = new System.Drawing.Point(21, 50);
            this.tableLayoutPanelCustomer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanelCustomer.Name = "tableLayoutPanelCustomer";
            this.tableLayoutPanelCustomer.RowCount = 6;
            this.tableLayoutPanelCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanelCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanelCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanelCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanelCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanelCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanelCustomer.Size = new System.Drawing.Size(200, 171);
            this.tableLayoutPanelCustomer.TabIndex = 23;
            this.tableLayoutPanelCustomer.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 17);
            this.label7.TabIndex = 23;
            this.label7.Text = "Adresse:";
            // 
            // adresseBox
            // 
            this.adresseBox.Location = new System.Drawing.Point(104, 142);
            this.adresseBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.adresseBox.Name = "adresseBox";
            this.adresseBox.Size = new System.Drawing.Size(93, 22);
            this.adresseBox.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 17);
            this.label6.TabIndex = 21;
            this.label6.Text = "Firma navn:";
            // 
            // firmaBox
            // 
            this.firmaBox.Location = new System.Drawing.Point(104, 114);
            this.firmaBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.firmaBox.Name = "firmaBox";
            this.firmaBox.Size = new System.Drawing.Size(93, 22);
            this.firmaBox.TabIndex = 20;
            // 
            // fornavnBox
            // 
            this.fornavnBox.Location = new System.Drawing.Point(104, 2);
            this.fornavnBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fornavnBox.Name = "fornavnBox";
            this.fornavnBox.Size = new System.Drawing.Size(93, 22);
            this.fornavnBox.TabIndex = 12;
            // 
            // tlfBox
            // 
            this.tlfBox.Location = new System.Drawing.Point(104, 58);
            this.tlfBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tlfBox.Name = "tlfBox";
            this.tlfBox.Size = new System.Drawing.Size(93, 22);
            this.tlfBox.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 19;
            this.label2.Text = "Kunde Type:";
            // 
            // kundeTypeBox
            // 
            this.kundeTypeBox.Location = new System.Drawing.Point(104, 86);
            this.kundeTypeBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kundeTypeBox.Name = "kundeTypeBox";
            this.kundeTypeBox.Size = new System.Drawing.Size(93, 22);
            this.kundeTypeBox.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "Fornavn:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 17;
            this.label4.Text = "Efternavn:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "Telefon NR:";
            // 
            // efternavnBox
            // 
            this.efternavnBox.Location = new System.Drawing.Point(104, 30);
            this.efternavnBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.efternavnBox.Name = "efternavnBox";
            this.efternavnBox.Size = new System.Drawing.Size(93, 22);
            this.efternavnBox.TabIndex = 16;
            // 
            // lavKundeKnap
            // 
            this.lavKundeKnap.Location = new System.Drawing.Point(64, 228);
            this.lavKundeKnap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lavKundeKnap.Name = "lavKundeKnap";
            this.lavKundeKnap.Size = new System.Drawing.Size(112, 95);
            this.lavKundeKnap.TabIndex = 22;
            this.lavKundeKnap.Text = "Create Customer";
            this.lavKundeKnap.UseVisualStyleBackColor = true;
            this.lavKundeKnap.Visible = false;
            this.lavKundeKnap.Click += new System.EventHandler(this.nyKundeKnap_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(20, 53);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1017, 270);
            this.dataGridView1.TabIndex = 24;
            this.dataGridView1.Visible = false;
            this.dataGridView1.Click += new System.EventHandler(this.DataGridView1_Click);
            // 
            // tableLayoutPanelRedigerKunde
            // 
            this.tableLayoutPanelRedigerKunde.ColumnCount = 8;
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.label14, 6, 0);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.label13, 5, 0);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.label12, 4, 0);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.label11, 3, 0);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.label10, 2, 0);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.label9, 1, 0);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.editFirmanavnBox, 6, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.button1, 7, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.editKundeTypeBox, 5, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.editTlfBox, 4, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.editKudnIDBox, 3, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.editAdresseBox, 2, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.editEfternavBox, 1, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.editnavnBox, 0, 1);
            this.tableLayoutPanelRedigerKunde.Controls.Add(this.label8, 0, 0);
            this.tableLayoutPanelRedigerKunde.Location = new System.Drawing.Point(21, 330);
            this.tableLayoutPanelRedigerKunde.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanelRedigerKunde.Name = "tableLayoutPanelRedigerKunde";
            this.tableLayoutPanelRedigerKunde.RowCount = 2;
            this.tableLayoutPanelRedigerKunde.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRedigerKunde.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRedigerKunde.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanelRedigerKunde.Size = new System.Drawing.Size(1016, 65);
            this.tableLayoutPanelRedigerKunde.TabIndex = 25;
            this.tableLayoutPanelRedigerKunde.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(766, 0);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 17);
            this.label14.TabIndex = 14;
            this.label14.Text = "Company Name:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(639, 0);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(108, 17);
            this.label13.TabIndex = 13;
            this.label13.Text = "Customer Type:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(512, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 17);
            this.label12.TabIndex = 12;
            this.label12.Text = "Phone NR:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(385, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 17);
            this.label11.TabIndex = 11;
            this.label11.Text = "Customer ID:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(258, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 17);
            this.label10.TabIndex = 10;
            this.label10.Text = "Adress:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(131, 0);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Lastname:";
            // 
            // editFirmanavnBox
            // 
            this.editFirmanavnBox.Location = new System.Drawing.Point(766, 36);
            this.editFirmanavnBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editFirmanavnBox.Name = "editFirmanavnBox";
            this.editFirmanavnBox.Size = new System.Drawing.Size(117, 22);
            this.editFirmanavnBox.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(893, 36);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 25);
            this.button1.TabIndex = 7;
            this.button1.Text = "Edit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.editKnap_Click);
            // 
            // editKundeTypeBox
            // 
            this.editKundeTypeBox.Location = new System.Drawing.Point(639, 36);
            this.editKundeTypeBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editKundeTypeBox.Name = "editKundeTypeBox";
            this.editKundeTypeBox.Size = new System.Drawing.Size(117, 22);
            this.editKundeTypeBox.TabIndex = 5;
            // 
            // editTlfBox
            // 
            this.editTlfBox.Location = new System.Drawing.Point(512, 36);
            this.editTlfBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editTlfBox.Name = "editTlfBox";
            this.editTlfBox.Size = new System.Drawing.Size(117, 22);
            this.editTlfBox.TabIndex = 4;
            // 
            // editKudnIDBox
            // 
            this.editKudnIDBox.Location = new System.Drawing.Point(385, 36);
            this.editKudnIDBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editKudnIDBox.Name = "editKudnIDBox";
            this.editKudnIDBox.Size = new System.Drawing.Size(117, 22);
            this.editKudnIDBox.TabIndex = 3;
            // 
            // editAdresseBox
            // 
            this.editAdresseBox.Location = new System.Drawing.Point(258, 36);
            this.editAdresseBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editAdresseBox.Name = "editAdresseBox";
            this.editAdresseBox.Size = new System.Drawing.Size(117, 22);
            this.editAdresseBox.TabIndex = 2;
            // 
            // editEfternavBox
            // 
            this.editEfternavBox.Location = new System.Drawing.Point(131, 36);
            this.editEfternavBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editEfternavBox.Name = "editEfternavBox";
            this.editEfternavBox.Size = new System.Drawing.Size(117, 22);
            this.editEfternavBox.TabIndex = 1;
            // 
            // editnavnBox
            // 
            this.editnavnBox.Location = new System.Drawing.Point(4, 36);
            this.editnavnBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editnavnBox.Name = "editnavnBox";
            this.editnavnBox.Size = new System.Drawing.Size(117, 22);
            this.editnavnBox.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 17);
            this.label8.TabIndex = 8;
            this.label8.Text = "Name:";
            // 
            // tableLayoutPaneleditAccount
            // 
            this.tableLayoutPaneleditAccount.ColumnCount = 8;
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPaneleditAccount.Controls.Add(this.label17, 4, 0);
            this.tableLayoutPaneleditAccount.Controls.Add(this.label18, 3, 0);
            this.tableLayoutPaneleditAccount.Controls.Add(this.label19, 2, 0);
            this.tableLayoutPaneleditAccount.Controls.Add(this.label20, 1, 0);
            this.tableLayoutPaneleditAccount.Controls.Add(this.editPinkodeBox, 4, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.editSaldoBox, 3, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.editRenteBox, 2, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.editKontoTypeBox, 1, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.editKontoIDBox, 0, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPaneleditAccount.Controls.Add(this.editEjerBox, 5, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.label15, 5, 0);
            this.tableLayoutPaneleditAccount.Controls.Add(this.button2, 6, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.button3, 7, 1);
            this.tableLayoutPaneleditAccount.Controls.Add(this.søgKontoIDBox, 7, 0);
            this.tableLayoutPaneleditAccount.Controls.Add(this.label16, 6, 0);
            this.tableLayoutPaneleditAccount.Location = new System.Drawing.Point(21, 329);
            this.tableLayoutPaneleditAccount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPaneleditAccount.Name = "tableLayoutPaneleditAccount";
            this.tableLayoutPaneleditAccount.RowCount = 2;
            this.tableLayoutPaneleditAccount.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPaneleditAccount.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPaneleditAccount.Size = new System.Drawing.Size(1017, 66);
            this.tableLayoutPaneleditAccount.TabIndex = 26;
            this.tableLayoutPaneleditAccount.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(512, 0);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 17);
            this.label17.TabIndex = 12;
            this.label17.Text = "Pin Code:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(385, 0);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 17);
            this.label18.TabIndex = 11;
            this.label18.Text = "Balance:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(258, 0);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(93, 17);
            this.label19.TabIndex = 10;
            this.label19.Text = "Interest Rate:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(131, 0);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(99, 17);
            this.label20.TabIndex = 9;
            this.label20.Text = "Account Type:";
            // 
            // editPinkodeBox
            // 
            this.editPinkodeBox.Location = new System.Drawing.Point(512, 37);
            this.editPinkodeBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editPinkodeBox.Name = "editPinkodeBox";
            this.editPinkodeBox.Size = new System.Drawing.Size(117, 22);
            this.editPinkodeBox.TabIndex = 4;
            // 
            // editSaldoBox
            // 
            this.editSaldoBox.Location = new System.Drawing.Point(385, 37);
            this.editSaldoBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editSaldoBox.Name = "editSaldoBox";
            this.editSaldoBox.Size = new System.Drawing.Size(117, 22);
            this.editSaldoBox.TabIndex = 3;
            // 
            // editRenteBox
            // 
            this.editRenteBox.Location = new System.Drawing.Point(258, 37);
            this.editRenteBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editRenteBox.Name = "editRenteBox";
            this.editRenteBox.Size = new System.Drawing.Size(117, 22);
            this.editRenteBox.TabIndex = 2;
            // 
            // editKontoTypeBox
            // 
            this.editKontoTypeBox.Location = new System.Drawing.Point(131, 37);
            this.editKontoTypeBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editKontoTypeBox.Name = "editKontoTypeBox";
            this.editKontoTypeBox.Size = new System.Drawing.Size(117, 22);
            this.editKontoTypeBox.TabIndex = 1;
            // 
            // editKontoIDBox
            // 
            this.editKontoIDBox.Location = new System.Drawing.Point(4, 37);
            this.editKontoIDBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editKontoIDBox.Name = "editKontoIDBox";
            this.editKontoIDBox.Size = new System.Drawing.Size(117, 22);
            this.editKontoIDBox.TabIndex = 0;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(4, 0);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(80, 17);
            this.label21.TabIndex = 8;
            this.label21.Text = "Account ID:";
            // 
            // editEjerBox
            // 
            this.editEjerBox.Location = new System.Drawing.Point(639, 37);
            this.editEjerBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.editEjerBox.Name = "editEjerBox";
            this.editEjerBox.Size = new System.Drawing.Size(117, 22);
            this.editEjerBox.TabIndex = 6;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(639, 0);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 17);
            this.label15.TabIndex = 14;
            this.label15.Text = "Owner:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(766, 37);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 25);
            this.button2.TabIndex = 7;
            this.button2.Text = "Edit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.editKonti_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(893, 37);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(120, 25);
            this.button3.TabIndex = 28;
            this.button3.Text = "Search";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.søgKontoKnap_Click);
            // 
            // søgKontoIDBox
            // 
            this.søgKontoIDBox.Location = new System.Drawing.Point(893, 4);
            this.søgKontoIDBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.søgKontoIDBox.Name = "søgKontoIDBox";
            this.søgKontoIDBox.Size = new System.Drawing.Size(120, 22);
            this.søgKontoIDBox.TabIndex = 28;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(766, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label16.Size = new System.Drawing.Size(80, 17);
            this.label16.TabIndex = 29;
            this.label16.Text = "Account ID:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(20, 53);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(1017, 270);
            this.dataGridView2.TabIndex = 27;
            this.dataGridView2.Visible = false;
            this.dataGridView2.Click += new System.EventHandler(this.DataGridView2_Click);
            // 
            // tableLayoutPanelkundersøg
            // 
            this.tableLayoutPanelkundersøg.ColumnCount = 1;
            this.tableLayoutPanelkundersøg.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelkundersøg.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanelkundersøg.Controls.Add(this.button4, 0, 2);
            this.tableLayoutPanelkundersøg.Controls.Add(this.søgNavnBox, 0, 1);
            this.tableLayoutPanelkundersøg.Location = new System.Drawing.Point(531, 398);
            this.tableLayoutPanelkundersøg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanelkundersøg.Name = "tableLayoutPanelkundersøg";
            this.tableLayoutPanelkundersøg.RowCount = 3;
            this.tableLayoutPanelkundersøg.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.27273F));
            this.tableLayoutPanelkundersøg.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.36364F));
            this.tableLayoutPanelkundersøg.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.36364F));
            this.tableLayoutPanelkundersøg.Size = new System.Drawing.Size(200, 90);
            this.tableLayoutPanelkundersøg.TabIndex = 28;
            this.tableLayoutPanelkundersøg.Visible = false;
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(4, 0);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(192, 15);
            this.label22.TabIndex = 9;
            this.label22.Text = "Name:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(4, 60);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(192, 26);
            this.button4.TabIndex = 0;
            this.button4.Text = "Search";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.søgKundeKnap_Click);
            // 
            // søgNavnBox
            // 
            this.søgNavnBox.Location = new System.Drawing.Point(4, 28);
            this.søgNavnBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.søgNavnBox.Name = "søgNavnBox";
            this.søgNavnBox.Size = new System.Drawing.Size(191, 22);
            this.søgNavnBox.TabIndex = 10;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(20, 53);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(1017, 270);
            this.dataGridView3.TabIndex = 29;
            this.dataGridView3.Visible = false;
            this.dataGridView3.Click += new System.EventHandler(this.DataGridView3_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.button5, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.kundeKnap, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.kontoKnap, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.NewCustomerKnap, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.NewAccKnap, 3, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(28, 487);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(983, 100);
            this.tableLayoutPanel1.TabIndex = 30;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(395, 2);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(157, 95);
            this.button5.TabIndex = 9;
            this.button5.Text = "View Transactions";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.transaktionerKnap_Click);
            // 
            // tableLayoutPanelsøgTransaktion
            // 
            this.tableLayoutPanelsøgTransaktion.ColumnCount = 2;
            this.tableLayoutPanelsøgTransaktion.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelsøgTransaktion.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 148F));
            this.tableLayoutPanelsøgTransaktion.Controls.Add(this.sletTransaktionBox, 1, 1);
            this.tableLayoutPanelsøgTransaktion.Controls.Add(this.label24, 1, 0);
            this.tableLayoutPanelsøgTransaktion.Controls.Add(this.button7, 1, 2);
            this.tableLayoutPanelsøgTransaktion.Controls.Add(this.label23, 0, 0);
            this.tableLayoutPanelsøgTransaktion.Controls.Add(this.button6, 0, 2);
            this.tableLayoutPanelsøgTransaktion.Controls.Add(this.søgTransaktionBox, 0, 1);
            this.tableLayoutPanelsøgTransaktion.Location = new System.Drawing.Point(392, 324);
            this.tableLayoutPanelsøgTransaktion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tableLayoutPanelsøgTransaktion.Name = "tableLayoutPanelsøgTransaktion";
            this.tableLayoutPanelsøgTransaktion.RowCount = 3;
            this.tableLayoutPanelsøgTransaktion.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelsøgTransaktion.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelsøgTransaktion.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelsøgTransaktion.Size = new System.Drawing.Size(348, 159);
            this.tableLayoutPanelsøgTransaktion.TabIndex = 31;
            this.tableLayoutPanelsøgTransaktion.Visible = false;
            // 
            // sletTransaktionBox
            // 
            this.sletTransaktionBox.Location = new System.Drawing.Point(204, 57);
            this.sletTransaktionBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sletTransaktionBox.Name = "sletTransaktionBox";
            this.sletTransaktionBox.Size = new System.Drawing.Size(139, 22);
            this.sletTransaktionBox.TabIndex = 35;
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(204, 0);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(140, 30);
            this.label24.TabIndex = 34;
            this.label24.Text = "Transaktions NR:";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Red;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(204, 110);
            this.button7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(140, 38);
            this.button7.TabIndex = 33;
            this.button7.Text = "Delete";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.sletTransaktionKnap_Click);
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(4, 0);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(192, 30);
            this.label23.TabIndex = 9;
            this.label23.Text = "Account ID:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(4, 110);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(192, 43);
            this.button6.TabIndex = 0;
            this.button6.Text = "Search";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.søgTransaktionerKnap_Click);
            // 
            // søgTransaktionBox
            // 
            this.søgTransaktionBox.Location = new System.Drawing.Point(4, 57);
            this.søgTransaktionBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.søgTransaktionBox.Name = "søgTransaktionBox";
            this.søgTransaktionBox.Size = new System.Drawing.Size(191, 22);
            this.søgTransaktionBox.TabIndex = 10;
            // 
            // sletKundeKnap
            // 
            this.sletKundeKnap.BackColor = System.Drawing.Color.Red;
            this.sletKundeKnap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.sletKundeKnap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sletKundeKnap.Location = new System.Drawing.Point(404, 398);
            this.sletKundeKnap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sletKundeKnap.Name = "sletKundeKnap";
            this.sletKundeKnap.Size = new System.Drawing.Size(119, 28);
            this.sletKundeKnap.TabIndex = 32;
            this.sletKundeKnap.Text = "Delete";
            this.sletKundeKnap.UseVisualStyleBackColor = false;
            this.sletKundeKnap.Visible = false;
            this.sletKundeKnap.Click += new System.EventHandler(this.SletKundeKnap_Click);
            // 
            // sletKontoKnap
            // 
            this.sletKontoKnap.BackColor = System.Drawing.Color.Red;
            this.sletKontoKnap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.sletKontoKnap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sletKontoKnap.Location = new System.Drawing.Point(25, 398);
            this.sletKontoKnap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sletKontoKnap.Name = "sletKontoKnap";
            this.sletKontoKnap.Size = new System.Drawing.Size(119, 28);
            this.sletKontoKnap.TabIndex = 33;
            this.sletKontoKnap.Text = "Delete";
            this.sletKontoKnap.UseVisualStyleBackColor = false;
            this.sletKontoKnap.Visible = false;
            this.sletKontoKnap.Click += new System.EventHandler(this.SletKontoKnap_Click);
            // 
            // AdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1053, 634);
            this.Controls.Add(this.sletKontoKnap);
            this.Controls.Add(this.sletKundeKnap);
            this.Controls.Add(this.tableLayoutPanelsøgTransaktion);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.tableLayoutPanelkundersøg);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.tableLayoutPaneleditAccount);
            this.Controls.Add(this.tableLayoutPanelRedigerKunde);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tableLayoutPanelCustomer);
            this.Controls.Add(this.lavKundeKnap);
            this.Controls.Add(this.tableLayoutPanelAccount);
            this.Controls.Add(this.lavKontoKnap);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lukKnap);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AdminMenu";
            this.Text = "AdminMenu";
            this.tableLayoutPanelAccount.ResumeLayout(false);
            this.tableLayoutPanelAccount.PerformLayout();
            this.tableLayoutPanelCustomer.ResumeLayout(false);
            this.tableLayoutPanelCustomer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tableLayoutPanelRedigerKunde.ResumeLayout(false);
            this.tableLayoutPanelRedigerKunde.PerformLayout();
            this.tableLayoutPaneleditAccount.ResumeLayout(false);
            this.tableLayoutPaneleditAccount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tableLayoutPanelkundersøg.ResumeLayout(false);
            this.tableLayoutPanelkundersøg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanelsøgTransaktion.ResumeLayout(false);
            this.tableLayoutPanelsøgTransaktion.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button kundeKnap;
        private System.Windows.Forms.Button kontoKnap;
        private System.Windows.Forms.Button NewAccKnap;
        private System.Windows.Forms.Button lukKnap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button NewCustomerKnap;
        private System.Windows.Forms.Label labelKontoID;
        private System.Windows.Forms.TextBox kontoTypeBox;
        private System.Windows.Forms.Label labelRente;
        private System.Windows.Forms.TextBox renteBox;
        private System.Windows.Forms.Label labelSaldo;
        private System.Windows.Forms.TextBox saldoBox;
        private System.Windows.Forms.Label labelKundeID;
        private System.Windows.Forms.TextBox kundeIDBox;
        private System.Windows.Forms.Button lavKontoKnap;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelAccount;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelCustomer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button lavKundeKnap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox firmaBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox adresseBox;
        private System.Windows.Forms.TextBox fornavnBox;
        private System.Windows.Forms.TextBox tlfBox;
        private System.Windows.Forms.TextBox kundeTypeBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox efternavnBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelRedigerKunde;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox editFirmanavnBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox editKundeTypeBox;
        private System.Windows.Forms.TextBox editTlfBox;
        private System.Windows.Forms.TextBox editKudnIDBox;
        private System.Windows.Forms.TextBox editAdresseBox;
        private System.Windows.Forms.TextBox editEfternavBox;
        private System.Windows.Forms.TextBox editnavnBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPaneleditAccount;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox editEjerBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox editPinkodeBox;
        private System.Windows.Forms.TextBox editSaldoBox;
        private System.Windows.Forms.TextBox editRenteBox;
        private System.Windows.Forms.TextBox editKontoTypeBox;
        private System.Windows.Forms.TextBox editKontoIDBox;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox søgKontoIDBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelkundersøg;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox søgNavnBox;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelsøgTransaktion;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox søgTransaktionBox;
        private System.Windows.Forms.Button sletKundeKnap;
        private System.Windows.Forms.Button sletKontoKnap;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox sletTransaktionBox;
        private System.Windows.Forms.Label label24;
    }
}