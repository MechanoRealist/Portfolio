USE [K�rselsbog];
GO
INSERT MedarbejderK�rsel(FuldNavn, Nummerplade, Dato, Kilometer) VALUES ('Frederik', 'FN123456', '2019-04-01', 30);