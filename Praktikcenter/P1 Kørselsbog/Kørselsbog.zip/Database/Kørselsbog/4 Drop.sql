USE [K�rselsbog];
GO
DROP TABLE MedarbejderK�rsel;