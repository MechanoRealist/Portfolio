USE [K�rselsbog];
GO
INSERT MedarbejderK�rsel(FuldNavn, Nummerplade, Dato, Kilometer) VALUES ('Tom Khristensen', 'DB443290', '2019-03-28', 12),
						('Kim Jakobsen', 'HJ432199', '2019-03-25', 4),
						('Erik Svigermose', 'WE321569', '2019-03-19', 8);
